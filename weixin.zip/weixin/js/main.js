
//jQuery是一个js库,为我们封装了繁琐而常用的功能.
//只需要调用内部方法,就能轻松实现炫酷的效果
//jQuery基本语法:$(selecter).action();
//1.使用美元符号定义的jQuery函数
//2.selecter为选择器,完全兼容 css 选择器,标签选择器/id/派生
//3.antion()为要执行的函数

//记录当前的页面
var nowpage = 0;
//入口
$(document).ready(function(){
	//获取屏幕的宽高
	var width = window.innerWidth;
	var height = window.innerHeight;
	
	//最外层盒子的宽和高
	$(".content").width(width);
	$(".content").height(height*4);
	
//	每页的宽高
    $(".page").width(width);
    $(".page").height(height);
    
//  触控监听
    $(".content").swipe({
    	//fingerCount触控点
        //duration持续时间
       //distance距离
       //direction方向
       //event时件
    	swipe:function(event,direction,distance,duration,fingerCount){
    	if(direction =="up"){
    		nowpage = nowpage +1;
    	}
    	else if(direction == "down"){
               nowpage = nowpage - 1;    		
    	}
    	if(nowpage<0){
    		nowpage = 0;
    	}
    	if(nowpage>3){
    		nowpage = 3;
    	}
    	
    	//动画：移动content盒子的位置
    	//complete:an滑动页面，实现函数
    	$(".content").animate({top:nowpage*-100+"%"},{duration:500,complete:an});
    	}
    });
//     在触控监听外面  楼房淡入
          $(".page1-building").fadeIn(2000,function(){
//        	飞机变大
            $(".page1-avatar").animate({width:"70%"},{duration:1000});
          });
         
});


function an(){
	//判断如果滑到第二页
	if(nowpage ==1){
		//第二张背景淡入
          $(".page2-bg").fadeIn(2000,function(){
          	$(".page2-text1").fadeIn(1000,function(){
          		$(".page2-text2").fadeIn(1000);
          	});
          });
	}
	 if(nowpage ==2){
	 	$(".page3-title").fadeIn(1000);
	 	$(".page3-bustitle").fadeIn(1000);
	 	
	 	$(".page3-bus").animate({left:"-100%"},{duration:2000});
	 	$(".page3-avater").animate({right:"50%"},{duration:2000,complete:function(){
        //淡出
        $(".page3-title").fadeOut("slow",function(){display:none});
        $(".page3-bustitle").fadeOut("slow",function(){display:none});
        $(".page3-station").fadeOut("slow");
        $(".page3-avater").fadeOut("slow",function(){
        	$(".page3-wall").fadeIn("slow");
        	$(".page3-teamavatar").fadeIn("slow",function(){
        		$(".page3-space").animate({width:"30%"},{duration:1000,complete:function(){
        			$(".page3-where").animate({width:"50%"},{duration:1000});
        		}});
        	});
        });
	 	}});
	 }
}

var s = 0;
function start(img){
	if(s==0){
	img.src = "img/lightOn.png";
	s++;
	$(".page4-bg").fadeOut("slow");
	$(".page4-title").fadeOut("slow");
	$(".page4-guide").fadeOut("slow",function(){
		$(".page4-onbg").fadeIn("slow",function(){
			$(".page4-wky").fadeIn("slow");
		});
		
	});
	}else{
		img.src = "img/lightOff.png";
		s--;
	    $(".page4-bg").fadeIn("slow");
	    $(".page4-title").fadeIn("slow");
	    $(".page4-guide").fadeIn("slow",function(){
	    	$(".page4-onbg").fadeOut("slow");
		    $(".page4-wky").fadeOut("slow");
	    });
	}
}


function starts(img){
	var play = document.getElementById("musicbtn");
	if(play.paused){
		play.play();
		img.src = "img/musicBtn.png"
	}else{
		play.pause();
		img.src = "img/musicBtnOff.png"
	}
}
